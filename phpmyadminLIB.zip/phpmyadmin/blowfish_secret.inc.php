<?php
$cfg['blowfish_secret'] = '{LjzQa{w"^Ek7B,y-XqZtJ*>J@g4mQ_~';
