MongoDB PHP
-----------
Download from https://github.com/mongodb/mongo-php-library/releases

Import procedure:

- Copy all the files and folders from the folder mongodb/src in the cache/stores/mongodb/MongoDB directory.
- Copy the license file from the project root.
- Update thirdpartylibs.xml with the latest version.

This version (1.5.1) requires PHP mongodb extension >= 1.6.0
