<?php

class __Mustache_7b0a9ab920ba2dfd687d5c6d33ce4415 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        $buffer .= $indent . '<!-- Begin HTML generated from question_radio template. -->
';
        // 'qelements' section
        $value = $context->find('qelements');
        $buffer .= $this->sectionF40b5ff85307422e5a162a2f83416466($context, $indent, $value);
        $buffer .= $indent . '<!-- End HTML generated from question_radio template. -->';

        return $buffer;
    }

    private function section1dbc49004af5e34daef4cbad9023c94e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<span style="white-space:nowrap;">';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<span style="white-space:nowrap;">';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE6c044fe8710d3502dd5cb9686c32f3f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'checked="checked"';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'checked="checked"';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2eb10691007c92bdff260da6f5c039fd(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'disabled="disabled"';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'disabled="disabled"';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section467942d9eafbe49280f66de3336eed08(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'onclick="{{choice.onclick}}"';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'onclick="';
                $value = $this->resolveValue($context->findDot('choice.onclick'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '"';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section3528a83a0e89b76bcf06299a3504cced(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<input size="25" name="{{choice.oname}}" id="{{choice.oid}}" onclick="other_check(name)" value="{{choice.ovalue}}" type="text" /><label for="{{choice.oid}}" class="accesshide">{{{choice.olabel}}}</label>&nbsp;
';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<input size="25" name="';
                $value = $this->resolveValue($context->findDot('choice.oname'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" id="';
                $value = $this->resolveValue($context->findDot('choice.oid'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" onclick="other_check(name)" value="';
                $value = $this->resolveValue($context->findDot('choice.ovalue'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" type="text" /><label for="';
                $value = $this->resolveValue($context->findDot('choice.oid'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" class="accesshide">';
                $value = $this->resolveValue($context->findDot('choice.olabel'), $context);
                $buffer .= $value;
                $buffer .= '</label>&nbsp;
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA27340841fcc8695eb6ca99931a7d7e0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '</span>';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '</span>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionCc2c0fc4caad881ef58bff1b114cbf11(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
{{#choice.horizontal}}<span style="white-space:nowrap;">{{/choice.horizontal}}
<input id="{{choice.id}}" value="{{choice.value}}" name="{{choice.name}}" type="radio" {{#choice.checked}}checked="checked"{{/choice.checked}} {{#choice.disabled}}disabled="disabled"{{/choice.disabled}} {{#choice.onclick}}onclick="{{choice.onclick}}"{{/choice.onclick}}/>
<label for="{{choice.id}}">{{{choice.label}}}</label>
{{#choice.oname}}
<input size="25" name="{{choice.oname}}" id="{{choice.oid}}" onclick="other_check(name)" value="{{choice.ovalue}}" type="text" /><label for="{{choice.oid}}" class="accesshide">{{{choice.olabel}}}</label>&nbsp;
{{/choice.oname}}
{{#choice.horizontal}}</span>{{/choice.horizontal}}
{{^choice.horizontal}}<br />{{/choice.horizontal}}
';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                // 'choice.horizontal' section
                $value = $context->findDot('choice.horizontal');
                $buffer .= $this->section1dbc49004af5e34daef4cbad9023c94e($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '<input id="';
                $value = $this->resolveValue($context->findDot('choice.id'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" value="';
                $value = $this->resolveValue($context->findDot('choice.value'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" name="';
                $value = $this->resolveValue($context->findDot('choice.name'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" type="radio" ';
                // 'choice.checked' section
                $value = $context->findDot('choice.checked');
                $buffer .= $this->sectionE6c044fe8710d3502dd5cb9686c32f3f($context, $indent, $value);
                $buffer .= ' ';
                // 'choice.disabled' section
                $value = $context->findDot('choice.disabled');
                $buffer .= $this->section2eb10691007c92bdff260da6f5c039fd($context, $indent, $value);
                $buffer .= ' ';
                // 'choice.onclick' section
                $value = $context->findDot('choice.onclick');
                $buffer .= $this->section467942d9eafbe49280f66de3336eed08($context, $indent, $value);
                $buffer .= '/>
';
                $buffer .= $indent . '<label for="';
                $value = $this->resolveValue($context->findDot('choice.id'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '">';
                $value = $this->resolveValue($context->findDot('choice.label'), $context);
                $buffer .= $value;
                $buffer .= '</label>
';
                // 'choice.oname' section
                $value = $context->findDot('choice.oname');
                $buffer .= $this->section3528a83a0e89b76bcf06299a3504cced($context, $indent, $value);
                // 'choice.horizontal' section
                $value = $context->findDot('choice.horizontal');
                $buffer .= $this->sectionA27340841fcc8695eb6ca99931a7d7e0($context, $indent, $value);
                $buffer .= '
';
                // 'choice.horizontal' inverted section
                $value = $context->findDot('choice.horizontal');
                if (empty($value)) {
                    
                    $buffer .= $indent . '<br />';
                }
                $buffer .= '
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF40b5ff85307422e5a162a2f83416466(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
{{#choice}}
{{#choice.horizontal}}<span style="white-space:nowrap;">{{/choice.horizontal}}
<input id="{{choice.id}}" value="{{choice.value}}" name="{{choice.name}}" type="radio" {{#choice.checked}}checked="checked"{{/choice.checked}} {{#choice.disabled}}disabled="disabled"{{/choice.disabled}} {{#choice.onclick}}onclick="{{choice.onclick}}"{{/choice.onclick}}/>
<label for="{{choice.id}}">{{{choice.label}}}</label>
{{#choice.oname}}
<input size="25" name="{{choice.oname}}" id="{{choice.oid}}" onclick="other_check(name)" value="{{choice.ovalue}}" type="text" /><label for="{{choice.oid}}" class="accesshide">{{{choice.olabel}}}</label>&nbsp;
{{/choice.oname}}
{{#choice.horizontal}}</span>{{/choice.horizontal}}
{{^choice.horizontal}}<br />{{/choice.horizontal}}
{{/choice}}
';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                // 'choice' section
                $value = $context->find('choice');
                $buffer .= $this->sectionCc2c0fc4caad881ef58bff1b114cbf11($context, $indent, $value);
                $context->pop();
            }
        }
    
        return $buffer;
    }

}
