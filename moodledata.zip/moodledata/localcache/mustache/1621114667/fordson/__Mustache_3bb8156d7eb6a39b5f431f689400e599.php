<?php

class __Mustache_3bb8156d7eb6a39b5f431f689400e599 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '
';
        $buffer .= $indent . '<head><style>
';
        $buffer .= $indent . 'body:not(.dir-ltr):not(.dir-rtl) {
';
        $buffer .= $indent . '    font-family: \'Open Sans\', sans-serif;
';
        $buffer .= $indent . '}
';
        $buffer .= $indent . '.btn-insight {
';
        $buffer .= $indent . '    color: #007bff;
';
        $buffer .= $indent . '    background-color: transparent;
';
        $buffer .= $indent . '    display: inline-block;
';
        $buffer .= $indent . '    font-weight: 400;
';
        $buffer .= $indent . '    text-align: center;
';
        $buffer .= $indent . '    white-space: nowrap;
';
        $buffer .= $indent . '    vertical-align: middle;
';
        $buffer .= $indent . '    user-select: none;
';
        $buffer .= $indent . '    border: 1px solid #007bff;
';
        $buffer .= $indent . '    padding: .375rem .75rem;
';
        $buffer .= $indent . '    line-height: 1.5;
';
        $buffer .= $indent . '    border-radius: 0;
';
        $buffer .= $indent . '    text-decoration: none;
';
        $buffer .= $indent . '    cursor: pointer;
';
        $buffer .= $indent . '}
';
        $buffer .= $indent . '</style></head>
';

        return $buffer;
    }
}
