<?php

class __Mustache_ec77b1a64c9cb10ee70bfaf6181b8a9f extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        $buffer .= $indent . '<div class="box respondentsnavbar">
';
        $buffer .= $indent . '    ';
        // 'firstrespondent' section
        $value = $context->find('firstrespondent');
        $buffer .= $this->sectionDa472c5574a4776fb375c8ea316f6c57($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '    ';
        // 'previous' section
        $value = $context->find('previous');
        $buffer .= $this->sectionDcc00b0fbf94a98bc2988e02e7e37f42($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '    ';
        // 'respnumber' section
        $value = $context->find('respnumber');
        $buffer .= $this->sectionC90b58d2f47179803743501795992ab7($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '    ';
        // 'next' section
        $value = $context->find('next');
        $buffer .= $this->sectionE8fec2bdbf9a1890f7f83ecbbf0f229b($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '    ';
        // 'lastrespondent' section
        $value = $context->find('lastrespondent');
        $buffer .= $this->section82cedff0db263482b0fbeca3508781f5($context, $indent, $value);
        $buffer .= $indent . '    <br /><b>&lt;&lt;&lt; <a href="';
        $value = $this->resolveValue($context->find('listlink'), $context);
        $buffer .= call_user_func($this->mustache->getEscape(), $value);
        $buffer .= '">';
        // 'str' section
        $value = $context->find('str');
        $buffer .= $this->sectionC20313db66046ff8827a483e8035cd35($context, $indent, $value);
        $buffer .= '</a></b> | ';
        $value = $this->resolveValue($context->find('printaction'), $context);
        $buffer .= $value;
        $buffer .= '
';
        $buffer .= $indent . '</div>';

        return $buffer;
    }

    private function sectionA3be4dda7600df0e8f5811466af51dba(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'firstrespondent, mod_questionnaire';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'firstrespondent, mod_questionnaire';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDa472c5574a4776fb375c8ea316f6c57(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<b>&lt;&lt;</b> <a href="{{url}}" title="{{title}}">{{# str }}firstrespondent, mod_questionnaire{{/ str }}</a> |';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<b>&lt;&lt;</b> <a href="';
                $value = $this->resolveValue($context->find('url'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" title="';
                $value = $this->resolveValue($context->find('title'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '">';
                // 'str' section
                $value = $context->find('str');
                $buffer .= $this->sectionA3be4dda7600df0e8f5811466af51dba($context, $indent, $value);
                $buffer .= '</a> |';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section0ce7519556f02e689e63b4e03a15d9cc(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'previous, moodle';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'previous, moodle';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDcc00b0fbf94a98bc2988e02e7e37f42(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<b>&lt;</b> <a href="{{url}}" title="{{title}}">{{# str }}previous, moodle{{/ str }}</a> | ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<b>&lt;</b> <a href="';
                $value = $this->resolveValue($context->find('url'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" title="';
                $value = $this->resolveValue($context->find('title'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '">';
                // 'str' section
                $value = $context->find('str');
                $buffer .= $this->section0ce7519556f02e689e63b4e03a15d9cc($context, $indent, $value);
                $buffer .= '</a> | ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC90b58d2f47179803743501795992ab7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<b>{{currpos}} / {{total}}</b>';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<b>';
                $value = $this->resolveValue($context->find('currpos'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= ' / ';
                $value = $this->resolveValue($context->find('total'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '</b>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section559177a877044e1a1d916f561b7653e3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'next, moodle';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'next, moodle';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE8fec2bdbf9a1890f7f83ecbbf0f229b(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' | <a href="{{url}}" title="{{title}}">{{# str}}next, moodle{{/ str }}</a> <b>&gt;</b>';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' | <a href="';
                $value = $this->resolveValue($context->find('url'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" title="';
                $value = $this->resolveValue($context->find('title'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '">';
                // 'str' section
                $value = $context->find('str');
                $buffer .= $this->section559177a877044e1a1d916f561b7653e3($context, $indent, $value);
                $buffer .= '</a> <b>&gt;</b>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4665253a4ad37986a88c2983b8b5c441(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'lastrespondent, mod_questionnaire';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'lastrespondent, mod_questionnaire';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section82cedff0db263482b0fbeca3508781f5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' | <a href="{{url}}" title="{{title}}">{{# str }}lastrespondent, mod_questionnaire{{/ str }}</a> <b>&gt;&gt;</b>
    ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' | <a href="';
                $value = $this->resolveValue($context->find('url'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '" title="';
                $value = $this->resolveValue($context->find('title'), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '">';
                // 'str' section
                $value = $context->find('str');
                $buffer .= $this->section4665253a4ad37986a88c2983b8b5c441($context, $indent, $value);
                $buffer .= '</a> <b>&gt;&gt;</b>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC20313db66046ff8827a483e8035cd35(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'viewbyresponse, mod_questionnaire';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'viewbyresponse, mod_questionnaire';
                $context->pop();
            }
        }
    
        return $buffer;
    }

}
