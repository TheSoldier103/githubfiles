<?php

class __Mustache_3c8b9b3043eec8ee3cff5a755a4f6238 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<span class="sr-only sr-only-focusable" data-region="jumpto" tabindex="-1"></span>';

        return $buffer;
    }
}
