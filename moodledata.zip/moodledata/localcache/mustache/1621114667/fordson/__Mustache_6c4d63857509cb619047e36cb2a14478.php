<?php

class __Mustache_6c4d63857509cb619047e36cb2a14478 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        $buffer .= $indent . '<!-- Begin HTML generated from response_radio template. -->
';
        $buffer .= $indent . '<div class="questionnaire_response questionnaire_radio">
';
        // 'choices' section
        $value = $context->find('choices');
        $buffer .= $this->sectionB173af69bf559c116b7caff80341f450($context, $indent, $value);
        $buffer .= $indent . '</div>
';
        $buffer .= $indent . '<!-- End HTML generated from response_radio template. -->';

        return $buffer;
    }

    private function section1dbc49004af5e34daef4cbad9023c94e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<span style="white-space:nowrap;">';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<span style="white-space:nowrap;">';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section3d34ee93e05365a751b70ccfe9019ae5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '&#10003;';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '&#10003;';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB6dc2cb5b37e6be5260c7771858e2240(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' <span class="response text">{{.}}</span>';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' <span class="response text">';
                $value = $this->resolveValue($context->last(), $context);
                $buffer .= call_user_func($this->mustache->getEscape(), $value);
                $buffer .= '</span>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFa0cdd2152d562a2c2530e974d149917(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <span class="selected">
        {{^pdf}}<input type="radio" name="{{name}}" checked="checked" disabled="disabled" />{{/pdf}}
        {{#pdf}}&#10003;{{/pdf}} {{{content}}}{{#othercontent}} <span class="response text">{{.}}</span>{{/othercontent}}
    </span>
    ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    <span class="selected">
';
                $buffer .= $indent . '        ';
                // 'pdf' inverted section
                $value = $context->find('pdf');
                if (empty($value)) {
                    
                    $buffer .= '<input type="radio" name="';
                    $value = $this->resolveValue($context->find('name'), $context);
                    $buffer .= call_user_func($this->mustache->getEscape(), $value);
                    $buffer .= '" checked="checked" disabled="disabled" />';
                }
                $buffer .= '
';
                $buffer .= $indent . '        ';
                // 'pdf' section
                $value = $context->find('pdf');
                $buffer .= $this->section3d34ee93e05365a751b70ccfe9019ae5($context, $indent, $value);
                $buffer .= ' ';
                $value = $this->resolveValue($context->find('content'), $context);
                $buffer .= $value;
                // 'othercontent' section
                $value = $context->find('othercontent');
                $buffer .= $this->sectionB6dc2cb5b37e6be5260c7771858e2240($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '    </span>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4cbb13db81657f2a712f17cf2a4b6bb6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' color="gray"';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' color="gray"';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA27340841fcc8695eb6ca99931a7d7e0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '</span>';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '</span>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB173af69bf559c116b7caff80341f450(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
    {{#horizontal}}<span style="white-space:nowrap;">{{/horizontal}}
    {{#selected}}
    <span class="selected">
        {{^pdf}}<input type="radio" name="{{name}}" checked="checked" disabled="disabled" />{{/pdf}}
        {{#pdf}}&#10003;{{/pdf}} {{{content}}}{{#othercontent}} <span class="response text">{{.}}</span>{{/othercontent}}
    </span>
    {{/selected}}
    {{^selected}}
        <span class="unselected"{{#pdf}} color="gray"{{/pdf}}>{{^pdf}}<input type="radio" name="{{name}}" disabled="disabled" />{{/pdf}}
        {{{content}}}</span>&nbsp;
    {{/selected}}
    {{#horizontal}}</span>{{/horizontal}}
    {{^horizontal}}<br />{{/horizontal}}
';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    ';
                // 'horizontal' section
                $value = $context->find('horizontal');
                $buffer .= $this->section1dbc49004af5e34daef4cbad9023c94e($context, $indent, $value);
                $buffer .= '
';
                // 'selected' section
                $value = $context->find('selected');
                $buffer .= $this->sectionFa0cdd2152d562a2c2530e974d149917($context, $indent, $value);
                // 'selected' inverted section
                $value = $context->find('selected');
                if (empty($value)) {
                    
                    $buffer .= $indent . '        <span class="unselected"';
                    // 'pdf' section
                    $value = $context->find('pdf');
                    $buffer .= $this->section4cbb13db81657f2a712f17cf2a4b6bb6($context, $indent, $value);
                    $buffer .= '>';
                    // 'pdf' inverted section
                    $value = $context->find('pdf');
                    if (empty($value)) {
                        
                        $buffer .= '<input type="radio" name="';
                        $value = $this->resolveValue($context->find('name'), $context);
                        $buffer .= call_user_func($this->mustache->getEscape(), $value);
                        $buffer .= '" disabled="disabled" />';
                    }
                    $buffer .= '
';
                    $buffer .= $indent . '        ';
                    $value = $this->resolveValue($context->find('content'), $context);
                    $buffer .= $value;
                    $buffer .= '</span>&nbsp;
';
                }
                $buffer .= $indent . '    ';
                // 'horizontal' section
                $value = $context->find('horizontal');
                $buffer .= $this->sectionA27340841fcc8695eb6ca99931a7d7e0($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '    ';
                // 'horizontal' inverted section
                $value = $context->find('horizontal');
                if (empty($value)) {
                    
                    $buffer .= '<br />';
                }
                $buffer .= '
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

}
