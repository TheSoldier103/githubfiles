Redis Cache Store for Moodle
============================

A Moodle cache store plugin for [Redis](http://redis.io).

This plugin requires the [PhpRedis](https://github.com/nicolasff/phpredis) extension.  The PhpRedis extension can be installed via PECL with `pecl install redis`.
